---
layout: default
title: Security
---

# Security Configuration

This setting affects the security features of TinyMCE. The content security policy for the editor's iframe may be set here.

{% include configuration/security/content-security-policy.md %}

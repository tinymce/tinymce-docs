---
layout: default
title: Undo/Redo
---

# Undo and Redo Configuration

These settings change the behavior of undo and redo.

{% include configuration/undo-redo/custom-undo-redo-levels.md %}

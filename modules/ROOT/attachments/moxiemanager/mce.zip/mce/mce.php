<?php
/*
Plugin Name: MoxieManager
Plugin URI: http://www.moxiemanager.com/#
Description: Hookin for MoxieManager into Wordpress 2.6+, if you have issues, use the MoxieManager support ticket system for help.
Author: Moxiecode Systems AB
Version: 1.3
Author URI: http://www.moxiecode.com/
*/

// Don't run outside of WP
if ( ! defined('ABSPATH') ) {
	exit;
}

session_start();

function moxiecode_plugins_url($type) {
	// Get plugins location, can be either installed in the wp-content/plugins/<pluginname> folder or in the plugin folder of tinymce.
	if ( file_exists( ABSPATH . WPINC . '/js/tinymce/plugins/'. $type .'/plugin.min.js' ) ) {
		return includes_url( 'js/tinymce/plugins/'. $type .'/plugin.min.js' );
	} else if ( file_exists( WP_PLUGIN_DIR . '/' . $type .'/plugin.min.js' ) ) {
		return plugins_url( $type . '/plugin.min.js' );
	}
	
	// Return false if we cant find them
	return false;
}

function moxiecode_plugins_check($plugins) {
	$path = moxiecode_plugins_url("moxiemanager");
	// Set path to the editor_plugin.js file
	if ($path)
		$plugins["moxiemanager"] = $path;

	return $plugins;
}

function moxiecode_plugins_buttons($buttons) {
	$mm = moxiecode_plugins_url("moxiemanager");

	if ($mm)
		$buttons[] = "insertfile";

	/*
	// Check for tinymce-advanced plugin, for older WP advanced code, updated 2014-06-04
	$tadv_btns1 = (array) get_option('tadv_btns1');
	if (count($tadv_btns1) != 0) {
		// Seems like tinymce-advanced is installed
		$upd = false;
		
		// Check for insertfile button, and insert it if its not found
		if ($mm && !in_array("insertfile", $tadv_btns1)) {
			$tadv_btns1[] = "insertfile";
			$upd = true;
		}

		// Only update if we need to (usually only first time)
		if ($upd)
			update_option('tadv_btns1', $tadv_btns1);
	}
	*/
	return $buttons;
}

function moxiecode_plugins_init($user) {
	// Check if user can edit posts or edit pages
	if ( current_user_can('edit_posts') || current_user_can('edit_pages') ) {
		$mm = moxiecode_plugins_url("moxiemanager");
		
		// Get upload path
		$upload_path = get_option( 'upload_path' );
		if (trim($upload_path) === '')
			$upload_path = 'wp-content/uploads';

		$upload_path = path_join(ABSPATH, $upload_path);

		// Get daily path
		$up = wp_upload_dir();

		if ($mm)
			$_SESSION["isLoggedIn"] = true;

		if ($mm) {
			$_SESSION["moxiemanager.filesystem.rootpath"] = date("Y-m")."=". $up["path"] .";Archive=". $upload_path;
			$_SESSION["moxiemanager.filesystem.exclude_directory_pattern"] = '/^(mcith|js_cache)$/i';
		}

	} else {
		// Destroy the im/fm session
		if (isset($_SESSION["isLoggedIn"]))
			unset($_SESSION["isLoggedIn"]);
	}
}

// Check for the plugins, access and setup the sessions.
add_action('init', 'moxiecode_plugins_init');
// Check the paths and add it as plugins
add_filter('mce_external_plugins', 'moxiecode_plugins_check', 0);
// Add the buttons, also checks for tinymce-advanced plugin
add_filter("mce_buttons", "moxiecode_plugins_buttons");

?>
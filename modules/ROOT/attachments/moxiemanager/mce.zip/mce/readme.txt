
Installing MoxieManager for Wordpress 2.6+
------------------------------------------------------------

1. Download the latest version of the MoxieManager using your account at moxiemanager.com.

2. Unzip the contents of the zipfile into this folder:

/wp-includes/js/tinymce/plugins/

The folder structure should look like this since a folder is included in the file:

/wp-includes/js/tinymce/plugins/moxiemanager

3. Unzip the contents of this zipfile to /wp-content/plugins/

Folder structure should look like this:

/wp-content/plugins/mce/

The only files in that folder should be mce.php and this readme file.

4. Login to Wordpress as admin, activate the plugin in the plugins interface.

5. Create a new post or page, the editor should now have an extra button, click it and follow the installation instructions, choose the SessionAuthenticator and leave the session name instact as isLoggedIn.

6. Continue and save the config and you are done, you might have to logout/login to wordpress again for it to work.
﻿using MoxieManager.Core;
using MoxieManager.Core.Vfs;

namespace MoxieManager.Plugins.Example {
	/// <summary>
	///  This example plugin listens for basic file action events and logs these to a log file.
	///  You need to set log.enabled=true and log.level=debug in Web.Config to get output.
	/// </summary>
    public class Plugin : IPlugin {
        public void Init() {
			// Listen for file action events gets executed after file operations
			ManagerContext.Current.FileSystemManager.FileAction += delegate(object sender, FileActionEventArgs args) {
				switch (args.Action) {
					case FileAction.Add:
						ManagerContext.Current.Logger.Debug("Added new file: " + args.File.PublicPath);
						break;

					case FileAction.Delete:
						ManagerContext.Current.Logger.Debug("Removed new file: " + args.File.PublicPath);
						break;
				}
			};
        }
    }
}
